﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hntsystem2
{
    public partial class Form1 : Form
    {

        public static int hintCount = 0;
        public static double TotalCredit = 0;
        

        public Form1()
        {
            InitializeComponent();
            UpdateHintCountLabel();
            UpdateCreditCountLabel();
        }

        private void UpdateHintCountLabel()
        {
            hintLabel.Text = "Hints: " + hintCount.ToString();
        }

        private void UpdateCreditCountLabel()
        {
            label1.Text = $"Credits: $" + TotalCredit.ToString();
        }

        private void HintButton_Click(object sender, EventArgs e)
        {
            if (hintCount > 0)
            {
                hintCount--;
                pctrBox.Visible = false;
                HintButton.Visible = false;
                UpdateHintCountLabel();
            }
            else
            {
                MessageBox.Show("Buy hint at store.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (TotalCredit >= 100)
            {
                hintCount++;
                TotalCredit -= 100;
                UpdateHintCountLabel();
                UpdateCreditCountLabel();
            }
            else
            {
                MessageBox.Show("Not enough credits to purchase hint.");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (TotalCredit >= 350)
            {
                hintCount += 5;
                TotalCredit -= 350;
                UpdateHintCountLabel();
                UpdateCreditCountLabel();
            }
            else
            {
                MessageBox.Show("Not enough credits to purchase hints.");
            }
        }


        private void hintCountLabel_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void hintLabel_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2(hintCount, label1.Text);
            frm.Show();
            
        }

        private void enterBttn_Click(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox1.Text, "eagle"))
            {
                MessageBox.Show("Congratulations!");

                TotalCredit += 25;

                label1.Text = $"Credits: ${TotalCredit:F2}";
            }
            else
            {
                MessageBox.Show("Your answer is Incorrect");
            }
        }
    }
}
