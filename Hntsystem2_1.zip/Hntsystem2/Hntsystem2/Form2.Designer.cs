﻿namespace Hntsystem2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hintLabel = new System.Windows.Forms.Label();
            this.HintButton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.HintImage = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.enterBttn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.HintImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // hintLabel
            // 
            this.hintLabel.AutoSize = true;
            this.hintLabel.Location = new System.Drawing.Point(200, 143);
            this.hintLabel.Name = "hintLabel";
            this.hintLabel.Size = new System.Drawing.Size(43, 13);
            this.hintLabel.TabIndex = 6;
            this.hintLabel.Text = "Hints: 0";
            this.hintLabel.Click += new System.EventHandler(this.hintLabel_Click);
            // 
            // HintButton
            // 
            this.HintButton.Location = new System.Drawing.Point(183, 70);
            this.HintButton.Name = "HintButton";
            this.HintButton.Size = new System.Drawing.Size(75, 70);
            this.HintButton.TabIndex = 7;
            this.HintButton.Text = "HintButton";
            this.HintButton.UseVisualStyleBackColor = true;
            this.HintButton.Click += new System.EventHandler(this.HintButton_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(26, 36);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 8;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // HintImage
            // 
            this.HintImage.BackgroundImage = global::Hntsystem2.Properties.Resources.TAMARAW_H;
            this.HintImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.HintImage.Location = new System.Drawing.Point(39, 299);
            this.HintImage.Name = "HintImage";
            this.HintImage.Size = new System.Drawing.Size(187, 113);
            this.HintImage.TabIndex = 10;
            this.HintImage.TabStop = false;
            this.HintImage.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Hntsystem2.Properties.Resources.TAMARAW;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(39, 299);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(187, 113);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(192, 156);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Credits: 0";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(95, 223);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 12;
            // 
            // enterBttn
            // 
            this.enterBttn.Location = new System.Drawing.Point(105, 249);
            this.enterBttn.Name = "enterBttn";
            this.enterBttn.Size = new System.Drawing.Size(75, 23);
            this.enterBttn.TabIndex = 13;
            this.enterBttn.Text = "Enter";
            this.enterBttn.UseVisualStyleBackColor = true;
            this.enterBttn.Click += new System.EventHandler(this.enterBttn_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 464);
            this.Controls.Add(this.enterBttn);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HintImage);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.HintButton);
            this.Controls.Add(this.hintLabel);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.HintImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label hintLabel;
        private System.Windows.Forms.Button HintButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox HintImage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button enterBttn;
    }
}